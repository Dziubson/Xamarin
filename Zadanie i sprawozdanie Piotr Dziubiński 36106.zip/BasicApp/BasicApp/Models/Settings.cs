﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicApp.Models
{
   
    public class Settings
    {
       
        public int Id { get; set; }
    }
}
