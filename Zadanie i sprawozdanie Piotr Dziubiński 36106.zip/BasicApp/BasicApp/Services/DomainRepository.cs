﻿using BasicApp.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace BasicApp.Services
{

    public class DomainRepository : IDomainRepository
    {
       

        public Domains GetDomainData(int userID)
        {
            throw new NotImplementedException();
        }

        public void InsertDomain(Domains domains)
        {
            throw new NotImplementedException();
        }

        
    }
}


