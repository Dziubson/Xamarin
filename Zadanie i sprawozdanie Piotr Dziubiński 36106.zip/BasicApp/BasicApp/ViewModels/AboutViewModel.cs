﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BasicApp.ViewModels
{
    public class AboutViewModel : BaseViewModel
    {
        public AboutViewModel()
        {
        }
    }
}
